package com.example.project_kantor_lurah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
